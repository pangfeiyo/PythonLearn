﻿# *_* coding： UTF-8 *_*
# 开发团队：明日科技
# 明日学院网站：www.mingrisoft.com
# 开发工具：PyCharm
# 任务5：模拟成语填空游戏

print("两 全    美")
print("      乐")
print("      无")
print("      穷")
word = input("请输入所缺词语：")
print(word)
print("\n两 全\033[1;31m",word,"\033[0m美")
print("      乐")
print("      无")
print("      穷")