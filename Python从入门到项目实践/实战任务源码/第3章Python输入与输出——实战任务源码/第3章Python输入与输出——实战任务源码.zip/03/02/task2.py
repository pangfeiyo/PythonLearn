﻿# *_* coding： UTF-8 *_*
# 开发团队：明日科技
# 明日学院网站：www.mingrisoft.com
# 开发工具：PyCharm
# 任务2：模拟微信支付实现付款功能

a=input("\n请输入消费金额：\n")
print("付款金额为：", a)
print("支付成功，对方已收款\n")
